// let menu = document.querySelector("#menu")
// let menuBtn = document.querySelector(".icon")
// let menuBtnIcon = document.querySelector(".icon i")

// menuBtn.addEventListener("click",function (){
//     if (menuBtnIcon.classList.contains("fa-bars")){
//         menu.style.left = "0"
//         menuBtnIcon.classList = "fa fa-times"
//     } else {
//         menu.style.left = "-244px"
//         menuBtnIcon.classList = "fa fa-bars"
//     }
// })

let menu = document.querySelector("#meno");
let menuBtn = document.querySelector(".icon");
let menuBtnIcon = document.querySelector(".icon i");

menuBtn.addEventListener("click", function () {
    if (menuBtnIcon.classList.contains("fa-bars")) {
        menu.style.left = "0";
        menuBtnIcon.classList = "fa fa-times";
    } else {
        menu.style.left = "-244px";
        menuBtnIcon.classList = "fa fa-bars";
    }
});
